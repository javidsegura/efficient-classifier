### DYNAMIC CLASSIFICATION OF MALWARE IN ANDROID DEVICES

Dataset information: https://docs.google.com/document/d/1mhRRnYaBdi0t-SR_-fvgbhlN3trc-8hBZ2zbaO6rDUo/edit?usp=sharing

Complete feature context and malware descriptions (In progress): https://docs.google.com/document/d/1yH9gvnJVSH9GLv9ATQ5JQWA2z8Jy4umxxRfMF-y2fiU/edit?usp=sharing

First Iteration Revision: https://docs.google.com/document/d/10R3KM5mM6B9hlxaJ1DYlJZg84UExSFz1kMUTtvPc8fo/edit?usp=sharing

Contributions validation process: https://docs.google.com/spreadsheets/d/1tS9fax-VACRaC3rOBaCBGlC893oibwpqQq_D2NFLN_0/edit?usp=sharing